# Replicate all source file stats

plugin for [Unmanic](https://github.com/Unmanic)
