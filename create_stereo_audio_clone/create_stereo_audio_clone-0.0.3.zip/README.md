# Create stereo audio stream from surround sound

plugin for [Unmanic](https://github.com/Unmanic)
