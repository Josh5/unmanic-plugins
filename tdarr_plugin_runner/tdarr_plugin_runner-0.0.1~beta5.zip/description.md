

:::note
Currently, only the FFmpeg plugins are supported.
Once this plugin has been tested with a larger number of the Tdarr community plugins to ensure that it works as required, HandBrake CLI support will be enabled.
:::

---

#### How this plugin works:

This plugin provides a panel for installing, enabling and configuring Tdarr plugins from the Tdarr Community Plugins 
repository. 

All configuration of this plugin should be carried out in this [panel](/unmanic/ui/data-panels?pluginId=tdarr_plugin_runner).

From the panel you are able to install Tdarr plugins from the Tdarr community plugins repository.
Once installed you can enable and configure them on this page.
