# Ignore files over resolution

plugin for [Unmanic](https://github.com/Unmanic)
