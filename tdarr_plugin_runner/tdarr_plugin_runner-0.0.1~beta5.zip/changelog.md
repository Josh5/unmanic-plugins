
**<span style="color:#56adda">0.0.1~beta5</span>**
- Add missing ExifTool installation to plugin init script for the Unmanic Docker image

**<span style="color:#56adda">0.0.1~beta4</span>**
- Add ability to test files during the library scan against each enabled plugin
- Make the MediaInfo command optional as it is in Tdarr (disabled by default)

**<span style="color:#56adda">0.0.1~beta3</span>**
- Cache plugin details to speed up query times
- Add NodeJS Docker container installation script

**<span style="color:#56adda">0.0.1~beta2</span>**
- Fix bug in initial plugin downloads for a fresh install throwing error

**<span style="color:#56adda">0.0.1~beta1</span>**
- Initial version
